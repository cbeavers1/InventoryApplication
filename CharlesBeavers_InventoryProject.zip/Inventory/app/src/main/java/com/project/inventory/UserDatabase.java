package com.project.inventory;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.CharArrayBuffer;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class UserDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 1;

    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UserTable {
        private static final String TABLE = "user";
        private static final String COL_NAME = "userName";
        private static final String COL_PASS = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserDatabase.UserTable.TABLE + " (" +
                UserDatabase.UserTable.COL_NAME + " text primary key, " +
                UserDatabase.UserTable.COL_PASS + " text) ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + UserDatabase.UserTable.TABLE);
        onCreate(db);
    }

    public long addUser(String userName, String password) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserDatabase.UserTable.COL_NAME, userName);
        values.put(UserDatabase.UserTable.COL_PASS, password);

        long addID = db.insert(UserDatabase.UserTable.TABLE, null, values);

        return addID;
    }

    public long deleteUser(String userName, String password) {
        SQLiteDatabase db = getWritableDatabase();

        long deleteID = db.delete(UserDatabase.UserTable.TABLE, "where " + UserTable.COL_NAME + " = ?"
                + " and " + UserTable.COL_PASS + " = ?",
                new String[] { userName, password });

        return deleteID;
    }

    public boolean isIN(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        String name = "";
        String pass = "";
        boolean isIN = false;

        String sql = "select * from " + UserTable.TABLE + " where " + UserTable.COL_NAME + " = ?"
                + " and " + UserTable.COL_PASS + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { username, password});


        if (cursor.moveToFirst()) {
            do {
                name = cursor.getString(0);
                pass = cursor.getString(1);
            } while (cursor.moveToNext());

        }
        cursor.close();

        if (!name.isEmpty() && pass.equals(password)) {
            isIN = true;
        }

        return isIN;
    }
}
