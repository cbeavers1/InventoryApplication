package com.project.inventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class InventoryDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;

    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class InventoryTable {
        private static final String TABLE = "items";
        private static final String COL_NAME = "name";
        private static final String COL_QUANTITY = "quantity";
        private static final String COL_DESCRIPTION = "description";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_NAME + " text, " +
                InventoryTable.COL_QUANTITY + " integer, " +
                InventoryTable.COL_DESCRIPTION + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }



    public ArrayList<InventoryItem> getInventoryList() {
        String name;
        int quantity;
        String description;
        ArrayList<InventoryItem> inventoryList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + InventoryTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToFirst()) {
            do {
                name = cursor.getString(1);
                quantity = cursor.getInt(2);
                description = cursor.getString(3);
                InventoryItem item = new InventoryItem(name, quantity, description);
                inventoryList.add(item);
            } while (cursor.moveToNext());

        }
        cursor.close();
        return inventoryList;
    }

    public long addItem(InventoryItem item) {

        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_NAME, item.getItemName());
        values.put(InventoryTable.COL_QUANTITY, item.getQuantity());
        values.put(InventoryTable.COL_DESCRIPTION, item.getDescription());

        long itemID = db.insert(InventoryTable.TABLE, null, values);

        return itemID;
    }

    public boolean deleteItem(String name, int quantity, String description) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(InventoryTable.TABLE, InventoryTable.COL_NAME + " = ?" + " and " + InventoryTable.COL_QUANTITY + " = ?" + " and " + InventoryTable.COL_DESCRIPTION + " = ?", new String[] {name, String.valueOf(quantity), description});
        return rowsDeleted > 0;
    }

    public boolean updateItem(String newName, int newQuantity, String newDescription, String name, int quantity, String description){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_NAME, newName);
        values.put(InventoryTable.COL_QUANTITY, newQuantity);
        values.put(InventoryTable.COL_DESCRIPTION, newDescription);

        int rowsUpdated = db.update(InventoryTable.TABLE, values, InventoryTable.COL_NAME + " = ?"
                        + " and " + InventoryTable.COL_QUANTITY + " = ?"
                        + " and " + InventoryTable.COL_DESCRIPTION + " = ?", new String[] {name, String.valueOf(quantity), description});
        return rowsUpdated > 0;
    }
}