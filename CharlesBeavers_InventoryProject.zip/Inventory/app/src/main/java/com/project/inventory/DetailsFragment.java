package com.project.inventory;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DetailsFragment extends Fragment {

    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "name";
    private static final String ARG_PARAM2 = "quantity";
    private static final String ARG_PARAM3 = "description";
    private static final String ARG_PARAM4 = "iD";

    // Variables
    private String name;
    private int quantity;
    private String description;
    private int iD;

    // Views
    LinearLayout linDetails;
    Toolbar toolbarDetails;
    Button removeButton;
    Button updateButton;
    Button plusButton;
    Button minusButton;
    EditText itemNameText;
    EditText itemDescriptionText;
    EditText itemQuantityText;


    public DetailsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            name = getArguments().getString(ARG_PARAM1);
            quantity = getArguments().getInt(ARG_PARAM2);
            description = getArguments().getString(ARG_PARAM3);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View parentView = inflater.inflate(R.layout.fragment_details, container, false);

        // Initialize views and buttons
        toolbarDetails = parentView.findViewById(R.id.toolbarId);
        removeButton = parentView.findViewById(R.id.remove_button);
        updateButton = parentView.findViewById(R.id.update_button);
        itemNameText = parentView.findViewById(R.id.item_details_name);
        itemDescriptionText = parentView.findViewById(R.id.item_details_description);
        itemQuantityText = parentView.findViewById(R.id.det_quantity_edit);
        linDetails = parentView.findViewById(R.id.linear_details);
        plusButton = parentView.findViewById(R.id.det_plus_button);
        minusButton = parentView.findViewById(R.id.det_minus_button);

        // Set the text for item details name and description
        itemNameText.setText(name);
        itemDescriptionText.setText(description);
        itemQuantityText.setText(String.valueOf(quantity));

        // Returns to inventory
        toolbarDetails.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ListFragment listFragment = new ListFragment();
                FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
                transaction.replace(R.id.nav_host_fragment, listFragment).commit();
            }
        });

        // Removes item that was clicked to get to details page
        removeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ListFragment listFragment = new ListFragment();
                FragmentTransaction transaction = getParentFragmentManager().beginTransaction()
                        .setReorderingAllowed(true);

                // Creating arguments for list
                Bundle listArgs = new Bundle();
                listArgs.putString("name", name);
                listArgs.putInt("quantity", quantity);
                listArgs.putString("description", description);
                listArgs.putBoolean("remove", true);

                // Setting arguments and navigating
                listFragment.setArguments(listArgs);
                transaction.replace(R.id.nav_host_fragment, listFragment).commit();
            }
        });

        // Updates values based on new entry
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newName = itemNameText.getText().toString();
                String newDescription = itemDescriptionText.getText().toString();
                int newQuantity = Integer.parseInt(itemQuantityText.getText().toString());

                ListFragment listFragment = new ListFragment();
                FragmentTransaction transaction = getParentFragmentManager().beginTransaction()
                        .setReorderingAllowed(true);

                Bundle listArgs = new Bundle();
                listArgs.putString("name", name);
                listArgs.putInt("quantity", quantity);
                listArgs.putString("description", description);
                listArgs.putString("newName", newName);
                listArgs.putString("newDescription", newDescription);
                listArgs.putInt("newQuantity", newQuantity);
                listArgs.putBoolean("remove", false);

                listFragment.setArguments(listArgs);
                transaction.replace(R.id.nav_host_fragment, listFragment).commit();
            }
        });

        minusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (itemQuantityText.getText().toString().isEmpty()) {
                    return;
                }

                String quanEdit = itemQuantityText.getText().toString();
                int minusNum = Integer.parseInt(quanEdit);
                minusNum = minusNum - 1;

                if (minusNum < 0) {
                    minusNum = 0;
                }
                String nextVal = Integer.toString(minusNum);
                itemQuantityText.setText(nextVal);


            }
        });

        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (itemQuantityText.getText().toString().isEmpty()) {
                    return;
                }

                //Extract text from text box and increment
                String quanEdit = itemQuantityText.getText().toString();
                int plusNum = Integer.parseInt(quanEdit);
                plusNum = plusNum + 1;

                //Replace text with increment
                String nextVal = Integer.toString(plusNum);
                itemQuantityText.setText(nextVal);
            }
        });

        itemQuantityText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (itemQuantityText.getText().toString().equals("")) {
                    itemQuantityText.setText(String.valueOf(quantity));
                }
            }
        });

        return parentView;

    }
}