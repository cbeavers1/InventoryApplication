package com.project.inventory;

import android.Manifest;
import android.app.ActionBar;
import android.app.Application;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.DataSetObserver;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentResultListener;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;

import android.service.carrier.CarrierMessagingService;
import android.util.Log;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;

public class ListFragment extends Fragment {

    // Declare views and other variables
    FloatingActionButton fab;
    GridView list;
    ArrayList<InventoryItem> inventoryList;
    InventoryDatabase db;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment and instantiate inventory list
        View parentView = inflater.inflate(R.layout.fragment_list, container, false);

        // Initialize views and values
        list = parentView.findViewById(R.id.inventory_list);
        db = new InventoryDatabase(getContext());
        fab = parentView.findViewById(R.id.fabAdd);
        Toolbar toolbar = parentView.findViewById(R.id.toolbarIdList);

        // Set logout button
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), LoginActivity.class);
                startActivity(i);
                getActivity().finish();
            }
        });

        // Set notification button
        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                String permission = Manifest.permission.SEND_SMS;
                if (ContextCompat.checkSelfPermission(getContext(), permission) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(getActivity(), new String[] {permission}, 0);
                }
                else {
                    Toast.makeText(getContext(), "Permission Already Granted", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        // Delete or update
        Bundle removeArgs = getArguments();
        if (removeArgs != null) {
            String name = removeArgs.getString("name");
            int quantity = removeArgs.getInt("quantity");
            String description = removeArgs.getString("description");
            boolean removeBool = removeArgs.getBoolean("remove");

            if (removeBool) {
                db.deleteItem(name, quantity, description);
            }
            else {
                String newName = removeArgs.getString("newName");
                int newQuantity = removeArgs.getInt("newQuantity");
                String newDescription = removeArgs.getString("newDescription");

                db.updateItem(newName, newQuantity, newDescription, name, quantity, description);
            }
        }

        // Go to addFragment
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(fab).navigate(R.id.action_listFragment_to_addFragment2);
            }
        });
        return parentView;
    }

    // Use onResume to ensure all is updated when returning to fragment
    @Override
    public void onResume() {
        super.onResume();

        // Get data from addFragment
        getParentFragmentManager().setFragmentResultListener("requestKey", this, new FragmentResultListener() {
            @Override
            public void onFragmentResult(@NonNull String requestKey, @NonNull Bundle bundle) {
                String name = bundle.getString("name");
                int quantity = bundle.getInt("quantity");
                String description = bundle.getString("description");

                InventoryItem passItem = new InventoryItem(name, quantity, description);
                db.addItem(passItem);
            }
        });

        // Get all database items
        inventoryList = db.getInventoryList();

        // Create array and adapter
        ArrayList<String> list_items = new ArrayList<>();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this.getContext(), R.layout.single_list_item, list_items);

        for (int c = 0; c < inventoryList.size(); ++c) {

            // Fill adapter to set view text
            String listString = inventoryList.get(c).getItemName();
            String listString2 = Integer.toString(inventoryList.get(c).getQuantity());
            list_items.add(listString);
            list_items.add(listString2);

            //Navigates to details for viewing and removal.
            list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    if (i % 2 == 0) {
                        int j = i/2;

                        // Change color of item to see touch interaction
                        view.setBackgroundColor(getResources().getColor(R.color.dark_red));

                        // Initialize new detail fragment and start transaction
                        DetailsFragment detFragment = new DetailsFragment();
                        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();

                        // Create bundle for detail arguments
                        Bundle detArgs = new Bundle();
                        detArgs.putString("name", list.getItemAtPosition(i).toString());
                        detArgs.putString("description", inventoryList.get(j).getDescription());
                        detArgs.putInt("quantity", inventoryList.get(j).getQuantity());

                        // Set arguments and navigate to fragment
                        detFragment.setArguments(detArgs);
                        transaction.replace(R.id.nav_host_fragment, detFragment)
                                .commit();
                    }
                    else {
                        // Sets item click to corresponding name-column's item click for quantity column
                        this.onItemClick(adapterView, view, i-1, l);
                    }
                }
            });
        }
        //Assigns adapter to list
        list.setAdapter(adapter);
    }


}