package com.project.inventory;

import java.util.concurrent.atomic.AtomicInteger;

public class InventoryItem {

    // Declare variables
    private String itemName;
    private int quantity;
    private String description;
    private final int iD;
    public static AtomicInteger atomicID = new AtomicInteger();

    public InventoryItem(String itemName, int quantity, String description) {
        this.iD = atomicID.getAndIncrement();
        this.itemName = itemName;
        this.quantity = quantity;
        this.description = description;
    }

    public String getItemName() { return this.itemName; }
    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getQuantity() {
        return this.quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getDescription() { return this.description; }
    public void setDescription(String description) { this.description = description; }

    public int getID() { return this.iD; }
}
