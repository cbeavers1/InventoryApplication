package com.project.inventory;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.List;

public class AddFragment extends Fragment {

    public AddFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View parentView = inflater.inflate(R.layout.fragment_add, container, false);

        // Initialize views
        EditText itemNameText = parentView.findViewById(R.id.item_name_add);
        EditText itemDescriptionText = parentView.findViewById(R.id.item_description_add);
        EditText itemQuantityText = parentView.findViewById(R.id.quantity_edit);
        Button minusButton = parentView.findViewById(R.id.minus_button);
        Button plusButton = parentView.findViewById(R.id.plus_button);
        Button finishButton = parentView.findViewById(R.id.finish_add);
        Toolbar toolbar = parentView.findViewById(R.id.toolbarIdAdd);

        // Ensure that box stays 0
        itemQuantityText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (itemQuantityText.getText().toString().equals("")) {
                    itemQuantityText.setText("0");
                }
            }
        });

        // Navigates back to inventory list with no changes
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.action_addFragment_to_listFragment2);
            }
        });

        minusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (itemQuantityText.getText().toString().isEmpty()) {
                    return;
                }

                //Extract text from text box and decrement
                String quanEdit = itemQuantityText.getText().toString();
                int minusNum = Integer.parseInt(quanEdit);
                minusNum = minusNum - 1;

                if (minusNum < 0) {
                        minusNum = 0;
                }

                //Replace text with decrement
                String nextVal = Integer.toString(minusNum);
                itemQuantityText.setText(nextVal);


            }
        });

        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (itemQuantityText.getText().toString().isEmpty()) {
                    return;
                }

                //Extract text from text box and increment
                String quanEdit = itemQuantityText.getText().toString();
                int plusNum = Integer.parseInt(quanEdit);
                plusNum = plusNum + 1;

                //Replace text with increment
                String nextVal = Integer.toString(plusNum);
                itemQuantityText.setText(nextVal);
            }
        });

        // Sends item information to be added to list
        finishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!itemNameText.getText().toString().equals("") || itemQuantityText.getText() == null) {
                    Bundle args = new Bundle();
                    args.putString("name", itemNameText.getText().toString());
                    args.putInt("quantity", Integer.parseInt(itemQuantityText.getText().toString()));
                    args.putString("description", itemDescriptionText.getText().toString());

                    getParentFragmentManager().setFragmentResult("requestKey", args);
                    Navigation.findNavController(view).navigate(R.id.action_addFragment_to_listFragment2);
                }
                else {
                    Toast.makeText(getContext(), "Item needs a name", Toast.LENGTH_SHORT).show();

                }

            }
        });

        return parentView;
    }
}