package com.project.inventory;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.navigation.Navigation;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    UserDatabase db;
    Button login_button;
    Button create_button;
    EditText userNameText;
    EditText passwordText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        db = new UserDatabase(getApplicationContext());
        login_button = findViewById(R.id.login_button);
        userNameText = findViewById(R.id.username_entry);
        passwordText = findViewById(R.id.password_entry);
        create_button = findViewById(R.id.create_button);

        // Checks if user exists and password matches and navigates to inventory
        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (db.isIN(userNameText.getText().toString(), passwordText.getText().toString())) {
                    Intent i = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(i);
                    finish();
                }
                else {
                    Toast.makeText(getBaseContext(), "Incorrect username and password combination", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Adds new user to database
        create_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!db.isIN(userNameText.getText().toString(), passwordText.getText().toString())) {
                    if (userNameText.getText().toString().isEmpty() || passwordText.getText().toString().isEmpty()) {
                        Toast.makeText(getApplicationContext(), "Please enter username and password", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        db.addUser(userNameText.getText().toString(), passwordText.getText().toString());
                        Toast.makeText(getApplicationContext(), "User Account Created", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(getApplicationContext(), "User already exists", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}